# Nothing 2a RAM Tuner

A Magisk / KernelSU module that tunes memory management on the **Nothing Phone (2a)**
so more apps stay alive in the background and app switching feels smoother.

## What it does
| Tweak | Effect |
|---|---|
| `vm.swappiness` | Moves idle app memory to compressed zRAM sooner, freeing real RAM |
| `vm.vfs_cache_pressure` | Keeps filesystem metadata cached longer for faster app launches |
| `vm.page-cluster = 0` | Removes pointless read-ahead when pulling pages back from zRAM |
| Cached app freezer | Freezes background apps so they use no CPU (similar to iOS suspension) |
| Optional zRAM resize | Bigger / faster compressed swap (off by default) |

It deliberately does **not** drop caches or "kill background apps". Those tricks make
phones slower, because apps must cold-start again.

## Install
1. Download the latest zip from **Releases**.
2. Magisk: Modules > Install from storage. KernelSU: Module > Install.
3. Reboot.

## Configure
Edit `config.sh` in `/data/adb/modules/nothing2a_ram_tuner/` and reboot.

## Verify
Tap the module's **Action** button, or run `su -c cat /data/adb/modules/nothing2a_ram_tuner/tuner.log`.

## Uninstall
Remove the module and reboot. Everything reverts.

## Disclaimer
Use at your own risk. Requires root. Tested on: _(add your OS version here)_.

## License
MIT

## Author
Made by [robipoo](https://github.com/robipoo)
